package com.example.trungprojects;

public class BookACar {
    private int id;
    private String StartDate;
    private String EndDate;
    private String price;

    public BookACar(int id, String startDate, String endDate, String price) {
        this.id = id;
        StartDate = startDate;
        EndDate = endDate;
        this.price = price;
    }

    public BookACar(String startDate, String endDate, String price) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStartDate() {
        return StartDate;
    }

    public void setStartDate(String startDate) {
        StartDate = startDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String endDate) {
        EndDate = endDate;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "BookACar{" +
                "id=" + id +
                ", StartDate='" + StartDate + '\'' +
                ", EndDate='" + EndDate + '\'' +
                ", price=" + price +
                '}';
    }
}
